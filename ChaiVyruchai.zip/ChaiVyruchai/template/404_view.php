<header class="header container">
    <a href="index.html" class="header__logo"><picture><source srcset="img/logo/logo__full.webp" type="image/webp"><img src="img/logo/logo__full.png" alt="logo"></picture></a>
    <div>
    </div>
</header>
    <main class="main__oups oups container">
        <div class="oups__content">
            <div class="oups__colume">
                <h1 class="oups__title">404</h1>
                <p class="oups__description">УПС!... Кажется такой страницы нет.</p>
            </div>
        </div>
    </main>
    <footer class="footer">
                        <!-- Copyright -->
                <div class="footer__copyright copyright">
                    <div class="copyright__text">
                        &copy; <span class="footer__date"></span> <a href="https://chaivyruchai.ru"
                            class="copyright__description copyright__link">ChaiVyruchai.ru</a> Все права
                        защищены. Разработано <a href="https://dotdev.site"
                            class="copyright__description copyright__link" target="_blank">dotdev.site</a>
                    </div>
                </div>
                <!-- Copyright -->
    </footer>
