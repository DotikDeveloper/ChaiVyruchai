<?php
date_default_timezone_set('Europe/Volgograd');
$host = 'localhost';
$dbname = 'chaiv';
$user = 'root';
$pass = '';
