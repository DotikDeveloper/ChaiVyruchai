<?php
$paramsArray = array(
			'sector' => $this->params['sector'],
			'id' => $id,
			'client_ref' => $ref,
			'signature' => $signature,
		);