     <?php
        echo $data;
